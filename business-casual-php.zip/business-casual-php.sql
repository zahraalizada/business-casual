-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 31, 2023 at 08:00 PM
-- Server version: 8.0.27
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `business-casual-php`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
CREATE TABLE IF NOT EXISTS `about` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(500) NOT NULL,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `title`, `subtitle`, `content`, `image`, `slug`) VALUES
(1, 'Strong Coffee, Strong Roots', 'About Our Cafe', 'Founded in 1987 by the Hernandez brothers, our establishment has been serving up rich coffee sourced from artisan farmers in various regions of South and Central America. We are dedicated to travelling the world, finding the best coffee, and bringing back to you here in our cafe.\r\n\r\nWe guarantee that you will fall in lust with our decadent blends the moment you walk inside until you finish your last sip. Join us for your daily routine, an outing with friends, or simply just to enjoy some alone time. ', '1871273436bus-cas-about.jpg', 'strong-coffee-strong-roots');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

DROP TABLE IF EXISTS `admin_login`;
CREATE TABLE IF NOT EXISTS `admin_login` (
  `id` int NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `image` varchar(300) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `user_name`, `user_pass`, `image`) VALUES
(0, 'admin', 'admin', 'admin-login');

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

DROP TABLE IF EXISTS `home`;
CREATE TABLE IF NOT EXISTS `home` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(500) NOT NULL,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`id`, `title`, `subtitle`, `content`, `image`, `slug`) VALUES
(1, 'Fresh Coffee', 'Worth Drinking', 'Every cup of our quality artisan coffee starts with locally sourced, hand picked ingredients. Once you try it, our coffee will be a blissful addition to your everyday morning routine - we guarantee it!', '798539990bus-cas-home.jpg', 'fresh-coffee'),
(2, 'Our Promise', 'To You', 'When you walk into our shop to start your day, we are dedicated to providing you with friendly service, a welcoming atmosphere, and above all else, excellent products made with the highest quality ingredients. If you are not satisfied, please let us know and we will do whatever we can to make things right!', 'image 2', 'our-promise');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(500) NOT NULL,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `subtitle`, `content`, `image`, `slug`) VALUES
(1, 'Blended to Perfection', 'Coffees & Teas', '<p>We take pride in our work, and it shows. Every time you order a beverage\r\n from us, we guarantee that it will be an experience worth having. \r\nWhether it\'s our world famous Venezuelan Cappuccino, a refreshing iced \r\nherbal tea, or something as simple as a cup of speciality sourced black \r\ncoffee, you will be coming back for more.</p>', '1469414876bus-cas-products1.jpg', 'blended-to-perfection'),
(2, 'Delicious Treats, Good Eats', 'Bakery & Kitchen11', '<p>Our seasonal menu features delicious snacks, baked goods, and even full \r\nmeals perfect for breakfast or lunchtime. We source our ingredients from\r\n local, oragnic farms whenever possible, alongside premium vendors for \r\nspecialty goods.</p>', '1015802513bus-cas-products2.jpg', 'delicious-treats-good-eats'),
(3, 'From Around the World', 'Bulk Speciality Blends', '<p>Travelling the world for the very best quality coffee is something take \r\npride in. When you visit us, you\'ll always find new blends from around \r\nthe world, mainly from regions in Central and South America. We sell our\r\n blends in smaller to large bulk quantities. Please visit us in person \r\nfor more details.</p>', '1465962184bus-cas-products3.jpg', 'from-around-the-world');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
CREATE TABLE IF NOT EXISTS `store` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`id`, `title`, `subtitle`, `slug`, `street`, `address`, `phone`) VALUES
(1, 'Come On In', 'We\'re Open', 'come-on-in', '1116 Orchard Street ', 'Golden Valley, Minnesota ', '(317) 585-8468 ');

-- --------------------------------------------------------

--
-- Table structure for table `work_time`
--

DROP TABLE IF EXISTS `work_time`;
CREATE TABLE IF NOT EXISTS `work_time` (
  `id` int NOT NULL AUTO_INCREMENT,
  `work_key` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `work_value` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `work_time`
--

INSERT INTO `work_time` (`id`, `work_key`, `work_value`) VALUES
(1, 'Sunday', 'Closed'),
(2, 'Monday', '7:00 AM to 8:00 PM'),
(3, 'Tuesday ', '7:00 AM to 8:00 PM'),
(4, 'Wednesday', '7:00 AM to 8:00 PM'),
(5, 'Thursday', '7:00 AM to 8:00 PM'),
(6, 'Friday', '7:00 AM to 8:00 PM'),
(7, 'Saturday', '9:00 AM to 5:00 PM');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
